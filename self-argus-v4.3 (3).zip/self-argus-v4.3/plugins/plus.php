 ﻿<?php

if (in_array($userID, $admins)){
if(strpos($msg,"/download ") !== false){
         $req = trim(str_replace("/download ","",$msg));
         $req = explode("|",$req."|");
         $link = trim($req[0]);
         $name = trim($req[1]);
         $header = get_headers($link,true);
         if(isset($header['Content-Length'])){
          $file_size = $header['Content-Length'];
         }else{
          $file_size = -1;
         }
         $sizeLimit = ( 40 * 1024 * 1024);
         if($name==""){
          $name=explode("/",$link);
          $name = $name[sizeof($name)-1];
         }
         if($file_size > 0 && $file_size <= $sizeLimit ){
          $txt = "⏳ <b>Downloading Wait...</b> ".$name."";
          $m = $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $mid , 'message' => $txt, 'parse_mode' => 'HTML' ]);
          if(isset($m['updates'][0]['id'])){
           $mid = $m['updates'][0]['id'];
          }else{
           $mid = $m['id'];
          }
          
          $file = file_get_contents($link);
          $localFile = 'dl/'.$name;
          file_put_contents($localFile,$file);
          $txt = "⏳ <b>Uploading...</b> ".$name."";
          $ed = $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $mid, 'message' => $txt, 'parse_mode' => 'html' ]);
          $caption = '☂'.$name.'|@aralbots';
          
          $inputFile = $MadelineProto->upload($localFile);
          $txt = "⏳ Sending Wait plz...: <b>".$name."</b>";
          $ed = $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $mid, 'message' => $txt, 'parse_mode' => 'html' ]);
          $inputMedia = ['' => 'inputMediaUploadedDocument', 'file' => $inputFile, 'mime_type' => mime_content_type($localFile), 'caption' => $caption, 'attributes' => [['' => 'documentAttributeFilename', 'file_name' => $name]]];
          
          $p = ['peer' => $chatID, 'media' => $inputMedia];
          $res = $MadelineProto->messages->sendMedia($p);
          unlink($localFile);
          
          $txt = "🔰 <b>Sent!</b> 😉";
          $ed = $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $mid, 'message' => $txt, 'parse_mode' => 'html' ]);
          
          
         }else{
          $text = "❌ Max File Size: <b>".($sizeLimit / 1024 /1024 )."MB</b> but your file is <b>".round(($file_size/1024/1024),2)."MB</b>";
         }
}

if($userID==$admins and $msg =="/clean bots" || $msg=="clean bots" || $msg=="!clean bots" || $msg=="پاکسازی ربات ها" || $msg=="حذف ربات ها"){
$channelParticipantsRecent = ['_' => 'channelParticipantsRecent'];
$channels_ChannelParticipants = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' => $channelParticipantsRecent, 'offset' => 0, 'limit' => 200, 'hash' => 0, ]);
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$kl = $channels_ChannelParticipants['users'];
$list = "";
foreach($kl as $key=>$val){
$fon = $kl[$key]['bot'];
$fonid = $kl[$key]['id'];
if($fon == true){
$list .= ''.$kl[$key]['id']."\n";
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $fonid,
'banned_rights' => $channelBannedRights]);
}
}
$alaki = explode("\n",$list);
$allcount = count($alaki)-1;
$MadelineProto->messages->sendMessage(['peer'=>$chatID,'reply_to_msg_id'=>$msg_id,'message'=>"تعداد $allcount ربات از گروه شما پاک شد📍"]);
}



if ($userID == $admins){
if($msg =="/clean deleted" || $msg=="clean deleted" || $msg=="!clean deleted" || $msg=="پاکسازی دلت اکانت ها" || $msg=="حذف دلت اکانت ها"){
$channelParticipantsRecent = ['_' => 'channelParticipantsRecent'];
$channels_ChannelParticipants = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' => $channelParticipantsRecent, 'offset' => 0, 'limit' => 200, 'hash' => 0, ]);
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$kl = $channels_ChannelParticipants['users'];
$list = "";
foreach($kl as $key=>$val){
$fon = $kl[$key]['deleted'];
$fonid = $kl[$key]['id'];
if($fon == true){
$list .= ''.$kl[$key]['id']."\n";
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $fonid,
'banned_rights' => $channelBannedRights]);
}
}
$alaki = explode("\n",$list);
$allcount = count($alaki)-1;
$MadelineProto->messages->sendMessage(['peer'=>$chatID,'reply_to_msg_id'=>$msg_id,'message'=>"تعداد $allcount کاربر دیلیت اکانت از گروه شما پاک شد📍"]);
}}
if($msg == 'زمان'){
$time = file_get_contents('http://bit.ly/2pSzFdY');
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "$time"]);
}
if($msg == 'ساعت'){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '...']);
sleep(1);
for ($i=1; $i <= 50; $i++){
date_default_timezone_set("iran"); 
$ed = $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => date("H:i:s"),]);
sleep(1);
}
}

if(preg_match("/^[\/\#\!]?(خروج|left)$/i", $msg)){
  $type = $MadelineProto->get_info($chatID);
  $type3 = $type['type'];
  if($type3 == "supergroup"){
    $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "Bye!! :)"]);
    $MadelineProto->channels->leaveChannel(['channel' => $chatID, ]);
  }else{
    $MadelineProto->messages->sendMessage(['peer' => $chatID,'reply_to_msg_id' => $msg_id ,'message' => "این دستور مخصوص استفاده در سوپرگروه میباشد"]);
  }
}
if(strpos($msg, "/ram") !== false){
 $mem_using = round(memory_get_usage() / 1024 / 1024,1);
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "
♻️ مقدار رم درحال استفاده : $mem_using مگابایت
💡by: @mr_MJQ
", 'reply_to_msg_id' => $msg_id]);
}
if(strpos($msg, "!reboot") !== false){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "■□□□□❌", 'reply_to_msg_id' => $msg_id]);

sleep(0.5);

$ed = $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id +1, 'message' =>'□■□□□❌', 'parse_mode' => $msg_id]);

sleep(0.5);

$ed = $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id +1, 'message' =>'□□■□□❌', 'parse_mode' => $msg_id]);
sleep(0.5);

$ed = $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id +1, 'message' =>'□□□■□❌', 'parse_mode' => $msg_id]);
sleep(0.5);

$ed = $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id +1, 'message' =>'□□□□■❌', 'parse_mode' => $msg_id]);
sleep(0.5);

$ed = $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id +1, 'message' =>'■■■■■✅', 'parse_mode' => $msg_id]);

sleep(0.5);

$ed = $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id +1, 'message' =>'Bot is rebooted✅', 'parse_mode' => $msg_id]);
}
if(preg_match("/^[\/\#\!]?(pic) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(pic) (.*)$/i", $msg, $text);
$txxxt = $text[2];
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@pic", 'peer' => $chatID, 'query' => $txxxt, 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][rand(0, count($messages_BotResults['results']))]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
if(preg_match("/^[\/\#\!]?(gif) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(gif) (.*)$/i", $msg, $text);
$txxxt = $text[2];
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@gif", 'peer' => $chatID, 'query' => $txxxt, 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][rand(0, count($messages_BotResults['results']))]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
       }
if(preg_match("/^[\/\#\!]?(google) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(google) (.*)$/i", $msg, $text);
$txxxt = $text[2];
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@GoogleDEBot", 'peer' => $chatID, 'query' => $txxxt, 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][rand(0, count($messages_BotResults['results']))]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
if(preg_match("/^[\/\#\!]?(joke)$/i", $msg)){
preg_match("/^[\/\#\!]?(joke)$/i", $msg, $text);
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@function_robot", 'peer' => $chatID, 'query' => '', 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
if(preg_match("/^[\/\#\!]?(calc) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(calc) (.*)$/i", $msg, $text);
$txxxt = $text[2];
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@MACLBot", 'peer' => $chatID, 'query' => $txxxt, 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
if(preg_match("/^[\/\#\!]?(apk) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(apk) (.*)$/i", $msg, $text);
$txxxt = $text[2];
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@apkdl_bot", 'peer' => $chatID, 'query' => $txxxt, 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}

if(preg_match("/^[\/\#\!]?(translate) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(translate) (.*)$/i", $msg, $text);
$txxxt = $text[2];
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@TransisBot", 'peer' => $chatID, 'query' => $txxxt, 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
if(strpos($msg,"/hidden ") !== false){
$ip = trim(str_replace("/hidden ","",$msg));
$ip = explode("|",$ip."|||||");
$txxt = trim($ip[0]);
$answeer = trim($ip[1]);
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@nnbbot", 'peer' => $chatID, 'query' => "$txxt $answeer", 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
if(preg_match("/^[\/\#\!]?(like) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(like) (.*)$/i", $msg, $text);
$txxxt = $text[2];
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@like", 'peer' => $chatID, 'query' => $txxxt, 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
if(preg_match("/^[\/\#\!]?(del) (.*)$/", $msg)){
preg_match("/^[\/\#\!]?(del) (.*)$/", $msg, $text1);
$a=$text1[2];
for($c=0; $c<$a; $c++){
$mga=$msg_id-$c;
try{
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$mga], ]);
}catch(\danog\MadelineProto\RPCErrorException $e){
 }catch(\danog\MadelineProto\Exception $e){
    }catch(\danog\MadelineProto\TL\Conversion\Exception $e){
 }
}
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>"● پاکسازی به طور کامل انجام شد تعداد : $a پیام حذف شدند"]); 
}
if ($msg =="/chatid" ||$msg=="!chatid" ||$msg=="#chatid"){ 
    $me = $mee['User'];
    $me_id = $me['id'];
$MadelineProto->messages->sendMessage(['peer' =>$chatID,'reply_to_msg_id' => $msg_id ,'message' =>  "$chatID $me_id",'parse_mode' => 'MarkDown']);
}
if(preg_match("/^[\/\#\!]?(id) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(id) (.*)$/i", $msg, $text);
$mee = $MadelineProto->get_full_info($text[2]);
$me = $mee['User'];
$me_id = $me['id'];
$mes = "$me_id";
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "<code>$mes</code>  ",'parse_mode' => 'html']);

}


if(strpos(" ".$msg, "!setenemynam")){
  $prima = str_replace("!setenemynam ", "", $msg);
$myfile2 = fopen("enemynam.txt", "a") or die("Unable to open file!"); 
fwrite($myfile2, "$prima\n");
fclose($myfile2);
 $MadelineProto->messages->sendMessage(['peer' => $chatID,'reply_to_msg_id' => $msg_id ,'message' => "
➲ The target was added to the enemies list"]);
}
if(strpos(" ".$msg, "!delenemynam")){
  $prima3 = str_replace("/delenemynam ", "", $msg);
$newlist = str_replace($prima3, "", $enemy);
file_put_contents("enemynam.txt", $newlist);
 $MadelineProto->messages->sendMessage(['peer' => $chatID,'reply_to_msg_id' => $msg_id ,'message' => "➲The target was removed from the enemies list
"]);
}
if($msg == '!enemynamlist'){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "➲ List of robot enemies:

$enemy",'parse_mode' => 'MarkDown']);
}
//---
if($msg == "!enemynamon"){
 file_put_contents('badnam.txt','on');
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "➲Enemy encounter mode activated

If you set someone up as an enemy, the robot will start to curse him in the group from now on",'parse_mode' => 'MarkDown']);
}
if($msg == "!enemynamoff"){
 file_put_contents('badnam.txt','off');
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "➲Enemy encounter mode is disabled
The robot didn't do anything with the enemies",'parse_mode' => 'MarkDown']);
}
if(preg_match("/^[\/\#\!]?(cleanenemynam)$/i", $msg)){ 
   unlink("enemynam.txt"); 
   $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "➲ The robot's enemies list is empty",'parse_mode' => 'MarkDown']);
}
  if(preg_match("/^[\/\#\!]?(logo) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(logo) (.*)$/i", $msg, $text);
$txxxt = $text[2];
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@telsbot", 'peer' => $chatID, 'query' => "?text=$txxxt&page=1", 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][rand(0, count($messages_BotResults['results']))]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
       }
if (in_array($userID, $admins)){
if($msg == 'Creator' || $msg == '/creator' || $msg == 'creator'){
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@like", 'peer' => $chatID, 'query' => "#e2c80192c26727610", 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
}
if(preg_match("/^[\/\#\!]?(ip) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(ip) (.*)$/i", $msg, $text);
$txxxt = $text[2];
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@ip_loggerbot", 'peer' => $chatID, 'query' => $txxxt, 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
}