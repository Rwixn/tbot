﻿<?php

if (in_array($userID, $admins)){
if($msg == 'ping' || $msg == '/ping' || $msg == 'ربات' || $msg == 'آنلاینی' || $msg == 'انلاینی'){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "bot is online✅", 'reply_to_msg_id' => $msg_id]);

}
}