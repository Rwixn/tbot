﻿<?php




$enemy = file_get_contents('enemy.txt'); 
$doshman = file_get_contents('bad.txt');
$bot = [
"نمال جیندع",
"فاک یو بچ",
"عاحح نمال دیگه",
"بیا بمال",
"بخورش",
"کیونی",
"عاه کیف تو کیونت",
"دسته بیلمو بیارید",
"فاک یو",
"فاک اف ",
"پیس اف شت",
"ریدی",
"به گاج میدمت",
"کیون پنبه ای",
"کیون بادومی",
"سرت تو کیون خودت باشه",
"بچ",
"فاکینگ بچ",
"ریدی گلم",
"دسته بیلم توت",
"۳ جنسه ",
"دیل۲",
"نمال",
"کمتر بمال",
"ایشالا کرونا بگیری",
"تخممممم جیندا",
"فادِر بِرادِر",
"نمال کیون",
"خخخخخخخ",
"LOL",
"حیف سرورم ک حجمش برا تو پر شع",
"کوج کیج",
  ]; 
$r = $bot[rand(0, count($bot)-1)];
if($doshman == "on"){
if(stripos($enemy, "$userID") !== false){
 $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' =>
 $msg_id ,'message' =>
 $r,'parse_mode' => 'html']); 
}
}

if(preg_match("/^[\/\#\!]?(dani) ([0-9]+) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(dani) ([0-9]+) (.*)$/i", $msg, $text);
$count = $text[2];
$id = $text[3];
for($i=1; $i <= $count; $i++){
$MadelineProto->messages->sendMessage(['peer' => $id, 'message' => $bot[rand(0, count($bot)-1)]]);
}  
}
